<?php
//---------------------------------//
//The R0$h@|\|
//		O	O
//		  |
//		 ***
//_________________________________//
//require('vendor/autoload.php');
require_once 'lib/Braintree.php';

Braintree\Configuration::environment('sandbox');
Braintree\Configuration::merchantId('2qt4vxkb943vtxfr');
Braintree\Configuration::publicKey('d7f5fxnv7cd634yb');
Braintree\Configuration::privateKey('3b6c9284aad5b60a36f5401205fa25fc');


