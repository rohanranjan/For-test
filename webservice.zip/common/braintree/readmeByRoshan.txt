1).on front braintree.php file change all your merchent details
2).on tests/setup.php change merchent detail tere also thanks
