<?php
	class booking {
		function getbookingid($user_id='1', $prefix='DMV'){
			//generate booking_id
			//$datenow = date("Y-m-d");
			//$checkbid = mysql_query("SELECT COUNT(*) FROM ".$table." WHERE DATE(created)='$datenow'");
			//$sequencedtoday = mysql_result($checkbid, 0, 0);
			//generate code:
			//$ymd = date('ymd');
			//$squence = $squencedtoday+1;
			//$squence = str_pad($squence,4,0,STR_PAD_LEFT);
			return $prefix.time().$user_id;
			
			/* $chars      = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			$booking_id = "DMV";
			for ($i = 0; $i < 17; $i++) {
				$booking_id .= $chars[mt_rand(0, strlen($chars) - 1)];
			} */
			
			//code end
		}
		
	} //end class booking
?>
