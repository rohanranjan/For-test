<?php
//echo "hello1"; die();
define('GOOGLE_API_KEY_DRIVER','AIzaSyB5MpYoqg7_zZDYKv7qePenn_KelWZeCH4');
define('GOOGLE_API_KEY_USER','AIzaSyA35oihmkDaMt8O_FcQZXRhmIVcIFGo-Ag');

class notification{
///function to send gcm notification

function pushGcm($token,$message,$user){
	
	 if($user=='driver')
		$api_key = GOOGLE_API_KEY_DRIVER;
	else if($user == 'user')
		$api_key = GOOGLE_API_KEY_USER;
		
	$fields = array(
				'registration_ids' => $token,
				'data' => $message
									);
        // Set POST variables
		//$url = 'https://fcm.googleapis.com/fcm/send';
		$url = 'https://gcm-http.googleapis.com/gcm/send';
        $headers = array(
            'Authorization: key=' . $api_key,
            'Content-Type: application/json'
        );

        // Open connection
        $ch = curl_init();
        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields,true));
 
        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }
        // Close connection
        curl_close($ch);
		//echo $message;
		//print_r($result);
        return $result;
    }
    //gcm ends
    
 function pushApns($token,$message,$user="user"){
						$message['alert']= $message['message'];
						$message['sound']= 'default';

					if($user=='driver')
					$pem = "Fcm/driverCK.pem";
				else if($user == 'user')
					$pem = "Fcm/dmvCK.pem";
					
					$deviceToken = $token['0'];
					// Put your private key's passphrase here:
					$passphrase = 1234;
					// Put your alert message here:
					//$message = 'My second push notification!';
					$ctx = stream_context_create();
							stream_context_set_option($ctx, 'ssl', 'local_cert', $pem);
							stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
							stream_context_set_option($ctx, 'ssl', 'cafile', 'Fcm/entrust_2048_ca.cer');
							//$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err,$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
							$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
                                        if (!$fp)
                                        exit("Failed to connect: $err $errstr" . PHP_EOL);
                                       // echo 'Connected to APNS' . PHP_EOL;
                                        $body['aps'] = $message;
                                        $payload = json_encode($body);
                                        $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
                                        $result = fwrite($fp, $msg, strlen($msg));
                                        if (!$result)
                                        $returnData ='Message not delivered';
                                        else
                                        $returnData = 'Message successfully delivered';
                                        fclose($fp);
										return ($returnData)?$returnData:"";
}
  //apns ends
   
    
 }//end notification class
