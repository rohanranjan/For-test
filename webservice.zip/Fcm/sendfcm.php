<?php
//echo "hello1"; die();
define('GOOGLE_API_KEY_DRIVER','AIzaSyB5MpYoqg7_zZDYKv7qePenn_KelWZeCH4');
define('GOOGLE_API_KEY_USER','AIzaSyA35oihmkDaMt8O_FcQZXRhmIVcIFGo-Ag');

require (__DIR__."/../aws/aws.php");

class notification{
///function to send gcm notification

function pushGcm($token,$message,$user){

    $token = $token[0];
    push_notification($token,$message,'android',$user);
    }
    //gcm ends
    
 function pushApns($token,$message,$user="user")
 {
     $token = $token[0];
     push_notification($token,$message,'ios',$user);

 }
 }//end notification class
