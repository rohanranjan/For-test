<?php
 class distance
    {
        
        function distanceoffline($lat1, $lon1, $lat2, $lon2, $unit="k")
        {
            $theta = $lon1 - $lon2;
            $dist  = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
            $dist  = acos($dist);
            $dist  = rad2deg($dist);
            $miles = $dist * 60 * 1.1515;
            $unit  = strtoupper($unit);
            
            if ($unit == "K") {
                return ($miles * 1.609344);
            } else if ($unit == "N") {
                return ($miles * 0.8684);
            } else {
                return $miles;
            }
        }
        
		
	function GetDrivingDistance($lat1, $lat2, $long1, $long2){
		$url = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=".$lat1.",".$long1."&destinations=".$lat2.",".$long2."&mode=driving&language=en-US";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		$response = curl_exec($ch);
		curl_close($ch);
		$response_a = json_decode($response, true);
		$dist = $response_a['rows']['0']['elements']['0']['distance']['text'];
		$distMtr = $response_a['rows']['0']['elements']['0']['distance']['value'];
		$time = $response_a['rows']['0']['elements']['0']['duration']['text'];
		$timeSec = $response_a['rows']['0']['elements']['0']['duration']['value'];
		$status = $response_a['rows']['0']['elements']['0']['status'];
		$address = trim($response_a['origin_addresses']['0'], '()');
		//return $response_a; die();
		
		return array('distance' => $dist,
					'distanceMeter'=>$distMtr,
					'time' => $time, 
					'timeSec'=>$timeSec,
					'address'=>$address
					);
	}
        
        
    } //end class distance


?>
